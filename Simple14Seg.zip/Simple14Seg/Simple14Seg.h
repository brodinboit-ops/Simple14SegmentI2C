#ifndef Simple14Seg_h
#define Simple14Seg_h

#include <Arduino.h>
#include <Wire.h>

// Minimalist Font: 0-9, +, -, A-Z (Upper and Lowercase mapped to Upper)
static const uint16_t PROGMEM _liteFont[] = {
  0x0C3F, 0x0006, 0x00DB, 0x008F, 0x00E6, 0x00ED, 0x00FD, 0x0007, 0x00FF, 0x00EF, // 0-9
  0x12C0, 0x0040, // + (index 10), - (index 11)
  0x00F7, 0x128F, 0x0039, 0x120F, 0x0079, 0x0071, 0x00BD, 0x00F6, 0x1209, 0x001E, // A-J
  0x2470, 0x0038, 0x0536, 0x2136, 0x003F, 0x00F3, 0x083F, 0x08F3, 0x00ED, 0x1201, // K-T
  0x003E, 0x0C30, 0x2836, 0x2D00, 0x1500, 0x0C09  // U-Z
};

class Simple14Seg : public Print {
  private:
    uint8_t _addr;
    uint16_t _buffer[4]; 
    uint8_t _cursor = 0;

    void writeCmd(uint8_t cmd) {
      Wire.beginTransmission(_addr);
      Wire.write(cmd);
      Wire.endTransmission();
    }

  public:
    Simple14Seg(uint8_t addr = 0x70) : _addr(addr) {}

    void begin() {
      Wire.begin();
      writeCmd(0x21);      // System Oscillator ON
      setBrightness(10);   // Default brightness
      setBlink(0);         // No blink
      clear();
      display();
    }

    void clear() {
      for(uint8_t i=0; i<4; i++) _buffer[i] = 0;
      _cursor = 0;
    }

    void setCursor(uint8_t pos) {
      if (pos < 4) _cursor = pos;
    }

    void setBrightness(uint8_t level) {
      if (level > 15) level = 15;
      writeCmd(0xE0 | level);
    }

    void setBlink(uint8_t mode) {
      // 0=Off, 1=2Hz, 2=1Hz, 3=0.5Hz
      writeCmd(0x80 | 0x01 | (mode << 1));
    }

    void scrollLeft() {
      for(uint8_t i=0; i<3; i++) _buffer[i] = _buffer[i+1];
      _buffer[3] = 0;
    }

    virtual size_t write(uint8_t c) {
      if (c == '.') {
        if (_cursor > 0) _buffer[_cursor - 1] |= 0x4000;
        else _buffer[3] |= 0x4000;
        return 1;
      }

      uint16_t mask = 0;
      if (c >= '0' && c <= '9') mask = pgm_read_word(&_liteFont[c - '0']);
      else if (c >= 'A' && c <= 'Z') mask = pgm_read_word(&_liteFont[c - 'A' + 12]);
      else if (c >= 'a' && c <= 'z') mask = pgm_read_word(&_liteFont[c - 'a' + 12]);
      else if (c == '+') mask = pgm_read_word(&_liteFont[10]);
      else if (c == '-') mask = pgm_read_word(&_liteFont[11]);
      else if (c == ' ') mask = 0x0000;

      _buffer[_cursor] = mask;
      _cursor = (_cursor + 1) % 4;
      return 1;
    }

    void display() {
      Wire.beginTransmission(_addr);
      Wire.write(0x00); 
      for (uint8_t i = 0; i < 4; i++) {
        Wire.write(_buffer[i] & 0xFF);
        Wire.write(_buffer[i] >> 8);
      }
      Wire.endTransmission();
    }
};
#endif